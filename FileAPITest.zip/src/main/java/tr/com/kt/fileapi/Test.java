package tr.com.kt.fileapi;

import tr.com.kt.fileapi.util.AccessTokenResponseBean;
import tr.com.kt.fileapi.util.AccessTokenRetrievalException;
import tr.com.kt.fileapi.util.DistributionItem;
import tr.com.kt.fileapi.util.PostRequestExecutionException;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author      Fikri Aydemir
 * @version     1.0
 * @since       2021-05-30
 */
public class Test {
    public static void main(String[] args)
    {
        testPurchaseInvoice();
        testPurchaseMultipleInvoice();
        testPurchaseOrderDistribution();
    }

    private static void testPurchaseInvoice(){
        //Test for "v2/purchase/invoice";
        String testFilePath = "D:\\FATURATEST.pdf";
        List<Integer> deliveryIdList = new ArrayList<>();
        deliveryIdList.add(1907);
        deliveryIdList.add(1903);
        String invoiceSerialNumber = "INCE42";
        String invoiceDate = "2020-02-05";
        APIHandle apiHandle = new APIHandle();
        String clientId = "7fb6f39154ad4b0f8c47d01ad3f6b102", clientSecret = "PmAMSu4aZwo+oNqtHUYQZCfyu3bwcS2kNRff8zpOtoHp0nNpfxqarQ==" ;
        try {
            AccessTokenResponseBean accessTokenBean = apiHandle.requestAccessTokenWithClientCredentials(clientId, clientSecret, "payments");
            String accessToken = accessTokenBean.getAccessToken();
            String apiResponse = apiHandle.callV2PurchaseInvoiceAPI(accessToken, testFilePath, invoiceDate, invoiceSerialNumber, deliveryIdList);
            System.out.println(apiResponse);

        } catch (AccessTokenRetrievalException | PostRequestExecutionException e) {
            e.printStackTrace();
        }
    }

    private static void testPurchaseMultipleInvoice(){
        //Test for "v2/purchase/invoice";
        String testFilePath = "D:\\FATURATEST.pdf";
        List<Integer> deliveryIdList = new ArrayList<>();
        deliveryIdList.add(1907);
        deliveryIdList.add(1993);
        String invoiceSerialNumber = "INCE42";
        String invoiceDate = "2020-02-05";
        APIHandle apiHandle = new APIHandle();
        String clientId = "7fb6f39154ad4b0f8c47d01ad3f6b102", clientSecret = "PmAMSu4aZwo+oNqtHUYQZCfyu3bwcS2kNRff8zpOtoHp0nNpfxqarQ==" ;
        try {
            AccessTokenResponseBean accessTokenBean = apiHandle.requestAccessTokenWithClientCredentials(clientId, clientSecret, "payments");
            String accessToken = accessTokenBean.getAccessToken();
            String apiResponse = apiHandle.callV2PurchaseMultipleInvoiceAPI(accessToken, testFilePath, invoiceDate, invoiceSerialNumber, deliveryIdList);
            System.out.println(apiResponse);

        } catch (AccessTokenRetrievalException | PostRequestExecutionException e) {
            e.printStackTrace();
        }
    }

    private static void testPurchaseOrderDistribution(){
        //Test for "v2/purchase/orderdistribution";
        String testFilePath = "D:\\FATURATEST.pdf";
        List<DistributionItem> distributionItemList = new ArrayList<>();
        Integer orderdetailDistributionId = 40800;
        boolean isRejected = true;
        Integer quantity = 5;
        Integer eTenderDeliveryId = 1200;
        String deliveryDate = "2021-01-05";
        String description = "testtttttt";
        String cargoName = "Elden Teslim";
        String cargoTrackingNumber = "42EMH";
        String wayBillNumber = "12321";
        String wayBillDate = "2021-01-05";
        DistributionItem distributionItem = new DistributionItem(orderdetailDistributionId, quantity, eTenderDeliveryId, deliveryDate, description, cargoName, cargoTrackingNumber, wayBillNumber, wayBillDate, isRejected);
        distributionItemList.add(distributionItem);
        APIHandle apiHandle = new APIHandle();
        String clientId = "7fb6f39154ad4b0f8c47d01ad3f6b102", clientSecret = "PmAMSu4aZwo+oNqtHUYQZCfyu3bwcS2kNRff8zpOtoHp0nNpfxqarQ==" ;
        try {
            AccessTokenResponseBean accessTokenBean = apiHandle.requestAccessTokenWithClientCredentials(clientId, clientSecret, "payments");
            String accessToken = accessTokenBean.getAccessToken();
            String apiResponse = apiHandle.callV2PurchaseOrderDistributionAPI(accessToken, testFilePath, distributionItemList );
            System.out.println(apiResponse);

        } catch (AccessTokenRetrievalException | PostRequestExecutionException e) {
            e.printStackTrace();
        }
    }
}
