package tr.com.kt.fileapi.util;

/**
 *
 * @author      Fikri Aydemir
 * @version     1.0
 * @since       2021-05-30
 */
public class DistributionItem {

    private Integer orderDetailDistributionId;
    private Integer quantity;
    private Integer eTenderDeliveryId;
    private  String deliveryDate;
    private  String description;
    private  String cargoName;
    private  String cargoTrackingNumber;
    private  String waybillNumber;
    private  String waybillDate;
    private  boolean isRejected;

    public DistributionItem() {
    }

    public DistributionItem(
            int orderDetailDistributionId,
            int quantity,
            int eTenderDeliveryId,
            String deliveryDate,
            String description,
            String cargoName,
            String cargoTrackingNumber,
            String waybillNumber,
            String waybillDate,
            boolean isRejected) {
        this.orderDetailDistributionId = orderDetailDistributionId;
        this.quantity = quantity;
        this.eTenderDeliveryId = eTenderDeliveryId;
        this.deliveryDate = deliveryDate;
        this.description = description;
        this.cargoName = cargoName;
        this.cargoTrackingNumber = cargoTrackingNumber;
        this.waybillNumber = waybillNumber;
        this.waybillDate = waybillDate;
        this.isRejected = isRejected;
    }

    public Integer getOrderDetailDistributionId() {
        return orderDetailDistributionId;
    }

    public void setOrderDetailDistributionId(Integer orderDetailDistributionId) {
        this.orderDetailDistributionId = orderDetailDistributionId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer geteTenderDeliveryId() {
        return eTenderDeliveryId;
    }

    public void seteTenderDeliveryId(Integer eTenderDeliveryId) {
        this.eTenderDeliveryId = eTenderDeliveryId;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCargoName() {
        return cargoName;
    }

    public void setCargoName(String cargoName) {
        this.cargoName = cargoName;
    }

    public String getCargoTrackingNumber() {
        return cargoTrackingNumber;
    }

    public void setCargoTrackingNumber(String cargoTrackingNumber) {
        this.cargoTrackingNumber = cargoTrackingNumber;
    }

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public String getWaybillDate() {
        return waybillDate;
    }

    public void setWaybillDate(String waybillDate) {
        this.waybillDate = waybillDate;
    }

    public boolean isRejected() {
        return isRejected;
    }

    public void setRejected(boolean rejected) {
        isRejected = rejected;
    }
}
