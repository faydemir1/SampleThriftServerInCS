package tr.com.kt.fileapi;

import com.google.gson.Gson;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import tr.com.kt.fileapi.util.AccessTokenResponseBean;
import tr.com.kt.fileapi.util.AccessTokenRetrievalException;
import tr.com.kt.fileapi.util.DistributionItem;
import tr.com.kt.fileapi.util.PostRequestExecutionException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author      Fikri Aydemir
 * @version     1.0
 * @since       2021-05-30
 */
public class APIHandle {

    public APIHandle() {
    }

    public String callV2PurchaseInvoiceAPI(String accessToken,
                                           String filePath,
                                           String invoiceDate,
                                           String invoiceSerialNumber,
                                           List<Integer> deliveryIdList) throws PostRequestExecutionException {
        String endPoint = "v2/purchase/invoice";

        try {

            HttpClient httpClient = null;
            HttpResponse response = null;
            httpClient = HttpClients.createDefault();

            HttpPost httpPost = new HttpPost("https://apitest.kuveytturk.com.tr/prep/" + endPoint);
            //HttpPost httpPost = new HttpPost("http://localhost:5002/" + endPoint);
            httpPost.addHeader("Authorization", "Bearer " + accessToken);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addTextBody("InvoiceDate", invoiceDate);
            builder.addTextBody("InvoiceNumberSerial", invoiceSerialNumber);

            for (int i = 0; i < deliveryIdList.size(); i++) {
                builder.addTextBody(String.format("DeliveryIdList[%d]", i), String.valueOf(deliveryIdList.get(i)));
            }

            builder.setCharset(StandardCharsets.UTF_8);
            File f = new File(filePath);
            builder.addBinaryBody("FileAttachment", f);

            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            response = httpClient.execute(httpPost);
            String responseText = fromHTTPResponseToString(response);
            return responseText;

        } catch (Exception e){
            PostRequestExecutionException exp = new PostRequestExecutionException(e.getMessage(), e, "POST request to v2/purchase/invoice API has failed! CAUSE: " + e.getCause());
            throw exp;
        }
    }

    public String callV2PurchaseMultipleInvoiceAPI(String accessToken,
                                           String filePath,
                                           String invoiceDate,
                                           String invoiceSerialNumber,
                                           List<Integer> deliveryIdList) throws PostRequestExecutionException {
        String endPoint = "v2/purchase/multipleinvoice";

        try {

            HttpClient httpClient = null;
            HttpResponse response = null;
            httpClient = HttpClients.createDefault();

            HttpPost httpPost = new HttpPost("https://apitest.kuveytturk.com.tr/prep/" + endPoint);
            //HttpPost httpPost = new HttpPost("http://localhost:5002/" + endPoint);
            httpPost.addHeader("Authorization", "Bearer " + accessToken);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.addTextBody("InvoiceDate", invoiceDate);
            builder.addTextBody("InvoiceNumberSerial", invoiceSerialNumber);

            for (int i = 0; i < deliveryIdList.size(); i++) {
                builder.addTextBody(String.format("DeliveryIdList[%d]", i), String.valueOf(deliveryIdList.get(i)));
            }

            builder.setCharset(StandardCharsets.UTF_8);
            File f = new File(filePath);
            builder.addBinaryBody("FileAttachment", f);

            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            response = httpClient.execute(httpPost);
            String responseText = fromHTTPResponseToString(response);
            return responseText;

        } catch (Exception e){
            PostRequestExecutionException exp = new PostRequestExecutionException(e.getMessage(), e, "POST request to v2/purchase/invoice API has failed! CAUSE: " + e.getCause());
            throw exp;
        }
    }

    public String callV2PurchaseOrderDistributionAPI(String accessToken,
                                           String filePath,
                                           List<DistributionItem> distributionItemList) throws PostRequestExecutionException {
        String endPoint = "v2/purchase/orderdistribution";

        try {

            HttpClient httpClient = null;
            HttpResponse response = null;
            httpClient = HttpClients.createDefault();

            HttpPost httpPost = new HttpPost("https://apitest.kuveytturk.com.tr/prep/" + endPoint);
            //HttpPost httpPost = new HttpPost("http://localhost:5002/" + endPoint);
            httpPost.addHeader("Authorization", "Bearer " + accessToken);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

            for (int i = 0; i < distributionItemList.size(); i++) {
                builder.addTextBody(String.format("DistributionList[%d].OrderDetailDistributionId", i), String.valueOf(distributionItemList.get(i).getOrderDetailDistributionId()));
                builder.addTextBody(String.format("DistributionList[%d].IsRejected", i), String.valueOf(distributionItemList.get(i).isRejected()));
                builder.addTextBody(String.format("DistributionList[%d].Quantity", i), String.valueOf(distributionItemList.get(i).getQuantity()));
                builder.addTextBody(String.format("DistributionList[%d].ETenderDeliveryId", i), String.valueOf(distributionItemList.get(i).geteTenderDeliveryId()));
                builder.addTextBody(String.format("DistributionList[%d].DeliveryDate", i), distributionItemList.get(i).getDeliveryDate());
                builder.addTextBody(String.format("DistributionList[%d].Description", i), distributionItemList.get(i).getDescription());
                builder.addTextBody(String.format("DistributionList[%d].CargoName", i), distributionItemList.get(i).getCargoName());
                builder.addTextBody(String.format("DistributionList[%d].CargoTrackingNumber", i), distributionItemList.get(i).getCargoTrackingNumber());
                builder.addTextBody(String.format("DistributionList[%d].WaybillNumber", i), distributionItemList.get(i).getWaybillNumber());
                builder.addTextBody(String.format("DistributionList[%d].WaybillDate", i), distributionItemList.get(i).getWaybillDate());
            }

            builder.setCharset(StandardCharsets.UTF_8);
            File f = new File(filePath);
            builder.addBinaryBody("FileAttachment", f);

            HttpEntity entity = builder.build();
            httpPost.setEntity(entity);
            response = httpClient.execute(httpPost);
            String responseText = fromHTTPResponseToString(response);
            return responseText;

        } catch (Exception e){
            PostRequestExecutionException exp = new PostRequestExecutionException(e.getMessage(), e, "POST request to v2/purchase/orderdistribution API has failed! CAUSE: " + e.getCause());
            throw exp;
        }
    }

    public AccessTokenResponseBean requestAccessTokenWithClientCredentials(
            String clientId,
            String clientSecret,
            String scope) throws AccessTokenRetrievalException {

        HttpClient httpClient = null;
        HttpResponse response = null;
        httpClient = HttpClients.createDefault();

        try {
            HttpPost httpPost = new HttpPost("https://idprep.kuveytturk.com.tr/api/connect/token");
            List<NameValuePair> params = new ArrayList<NameValuePair>(2);
            params.add(new BasicNameValuePair("grant_type", "client_credentials"));
            params.add(new BasicNameValuePair("scope", scope));
            params.add(new BasicNameValuePair("client_id", clientId));
            params.add(new BasicNameValuePair("client_secret", clientSecret));
            httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));

            // Execute and get the response
            response =  httpClient.execute(httpPost);
            String jsonStr = fromHTTPResponseToString(response);
            Gson gson = new Gson();
            AccessTokenResponseBean bean = gson.fromJson(jsonStr, AccessTokenResponseBean.class);
            bean.setHttpStatusCode(response.getStatusLine().getStatusCode());
            return bean;

        } catch (IOException e) {
            AccessTokenResponseBean errResponseBody = new AccessTokenResponseBean();
            errResponseBody.setError(e.getLocalizedMessage());
            errResponseBody.setErrorDescription("IO Exception occurred while making access token request!");
            AccessTokenRetrievalException exp = new AccessTokenRetrievalException(e.getMessage(), e, errResponseBody);
            throw exp;
        }
    }



    private  String fromHTTPResponseToString(org.apache.http.HttpResponse response) {
        InputStream inputStream = null;
        String result = null;
        try{
            HttpEntity entity = response.getEntity();
            inputStream = entity.getContent();

            // json is UTF-8 by default
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"), 8);
            StringBuilder sb = new StringBuilder();

            String line = null;
            while ((line = reader.readLine()) != null)
            {
                sb.append(line + "\n");
            }
            result = sb.toString();
            return result;

        } catch (Exception ex){
            return ex.getMessage();
        }
        finally {
            try{
                if(inputStream != null) inputStream.close();
            }
            catch(Exception ex){ return ex.getMessage();}
        }
    }
}
