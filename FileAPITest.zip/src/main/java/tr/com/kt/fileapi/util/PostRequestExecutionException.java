package tr.com.kt.fileapi.util;

/**
 *
 * @author      Fikri Aydemir
 * @version     1.0
 * @since       2021-05-30
 */
public class PostRequestExecutionException extends Exception{
    private String errorResponse;

    /**
     * Constructor
     *
     * @param message Holds the error message
     */
    public PostRequestExecutionException(String message) {
        super(message);
    }

    /**
     * Constructor
     *
     * @param message Holds the error message
     * @param e       Holds the original exception object
     */
    public PostRequestExecutionException(String message, Exception e) {
        super(message, e);
    }

    /**
     * Constructor
     *
     * @param message         Holds the error message
     * @param e               Holds the original exception object
     * @param errResponse Holds the error response object
     */
    public PostRequestExecutionException(String message, Exception e, String errResponse) {
        super(message, e);
        errorResponse = errResponse;
    }

    public String getErrorResponse() {
        return errorResponse;
    }

    public String getErrorDetailsIfAny() {
        if(errorResponse != null) {
            return "ErrorResponse = " + errorResponse +
                    ", ExceptionMessage = " + super.getMessage();
        } else {
            return "ExceptionMessage = " + super.getMessage();
        }
    }
}
