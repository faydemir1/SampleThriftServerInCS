package tr.com.kt.fileapi.util;

/**
 *
 * @author      Fikri Aydemir
 * @version     1.0
 * @since       2021-05-30
 */
public final class AccessTokenRetrievalException extends Exception {

    private AccessTokenResponseBean errorResponse;

    /**
     * Constructor
     *
     * @param  message Holds the error message
     * @param  e Holds the original exception object
     */
    public AccessTokenRetrievalException(String message, Exception e){
        super(message,e);
    }

    /**
     * Constructor
     *
     * @param  message Holds the error message
     * @param  e Holds the original exception object
     * @param  errResponseBean Holds the error response object
     */
    public AccessTokenRetrievalException(String message, Exception e, AccessTokenResponseBean errResponseBean){
        super(message,e);
        errorResponse = errResponseBean;
    }

    public AccessTokenResponseBean getErrorResponse() {
        return errorResponse;
    }

}
